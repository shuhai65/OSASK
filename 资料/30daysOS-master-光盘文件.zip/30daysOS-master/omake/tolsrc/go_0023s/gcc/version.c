#include "../include/ansidecl.h"
#include "version.h"

const char *const version_string = "3.2 (mingw special 20020817-1)";
